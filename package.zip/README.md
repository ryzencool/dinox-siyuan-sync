
# Dinox Sync

[中文版](./README_zh_CN.md)

## Plugin Description

Sync Dinox Notes to SiYuan

## How to Use

1. Create an empty notebook and copy its ID.
2. Go to the plugin settings page and enter the notebook ID and your Dinox API Key.
3. Click the sync button to start syncing.
