
# Dinox Sync 

[English](./README.md)


## 插件说明

同步Dinox 笔记到 思源

## 使用方法

1. 创建一个空的Notebook，复制该 notebook 的 ID
2. 在插件的设置页面中填写上述的 notebook ID，以及 Dinox 的 API Key
3. 点击同步按钮即可


